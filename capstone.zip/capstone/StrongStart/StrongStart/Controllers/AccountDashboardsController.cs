﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongStart.Data;
using StrongStart.Models;
using StrongStart.Models.ViewModel;

namespace StrongStart.Controllers
{
    public class AccountDashboardsController : Controller
    {
        private readonly StrongStartContext _context;
        private readonly ApplicationDbContext appcontext;
        private readonly UserManager<ApplicationUser> _userManager;
        
       public AccountDashboardsController(StrongStartContext context, ApplicationDbContext appContext)
        {
            _context = context;
            appcontext = appContext;
        } 

        // GET: AccountDashboards
        public async Task<IActionResult> Index()
        {
            //This is a tempory int that will be replaced when we have accounts set up
            String loggedInUserId = this.User.FindFirstValue(ClaimTypes.NameIdentifier); 
            AccountDashboard userInfo = new AccountDashboard();

        //   var user = User.Identity.Name;
        // var currentUser = appcontext.Users.FirstOrDefault(u => u.Id == loggedInUserId);
       // var vol = await _userManager.FindByIdAsync(loggedInUserId);
           var vol = appcontext.Users.Where(i => i.Id == loggedInUserId).SingleOrDefault();
             List<Training_Volunteer> volunteerTrainingList = _context.Training_Volunteers.Where(i => i.volunteerID == loggedInUserId).ToList();
             List<Training> trainingList = new List<Training>();
             foreach (var item in volunteerTrainingList)
             {
                 Training trainingSession = _context.Trainings.Where(i => i.trainingID == item.trainingID).FirstOrDefault();

                 trainingList.Add(trainingSession);

             }
             userInfo.volunteerId = vol.Id;
             userInfo.firstName = vol.FirstName;
             userInfo.lastName = vol.LastName;
             userInfo.Email = vol.Email;
             userInfo.Address = vol.Address;
             userInfo.Phone = vol.PhoneNumber;
             userInfo.City = vol.City;
             userInfo.Province = vol.Province;
             userInfo.trainingSessions = trainingList;

            //fuck
            return View("Details", userInfo); 
          
        }

        // GET: AccountDashboards/Details/5
        public async Task<IActionResult> Details(AccountDashboard userInfo)
        {
            if (userInfo == null)
            {
                return NotFound();
            }
            return View(userInfo);
        }

        // GET: AccountDashboards/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AccountDashboards/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,firstName,lastName,Email,Address,Phone,City,Province,volunteerId")] AccountDashboard accountDashboard)
        {
            if (ModelState.IsValid)
            {
                _context.Add(accountDashboard);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(accountDashboard);
        }

        // GET: AccountDashboards/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
         /*   if (id == null)
            {
                return NotFound();
            }

           // var accountDashboard = await _context.AccountDashboard.FindAsync(id);
            if (accountDashboard == null)
            {
                return NotFound();
            }
            */
            return NotFound();
        }

        // POST: AccountDashboards/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
      
      
    }
}

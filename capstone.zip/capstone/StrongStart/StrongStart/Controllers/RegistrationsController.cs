﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongStart.Models;
using Microsoft.AspNetCore.Http;
using static System.Collections.Specialized.BitVector32;
using StrongStart.Models.ViewModel;
using System.Security.Claims;
using StrongStart.Data;

namespace StrongStart.Controllers
{
    public class RegistrationsController : Controller
    {
        private readonly StrongStartContext _context;
        private readonly ApplicationDbContext appcontext;

        public RegistrationsController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: Registrations
        public async Task<IActionResult> Index()
        {

            var strongStartContext = _context.Trainings.Include(t => t.site).Include(t => t.term);
            String trainingID;
                trainingID = HttpContext.Session.GetString("training_id");

            if (trainingID != null)
            {
               int trainId = Convert.ToInt32(trainingID);
                HttpContext.Session.Remove("training_id");
                return RedirectToAction("Details", new { id = trainId });
            }
            else if (trainingID == null)
            {

            }
            List<Training> lst = await strongStartContext.ToListAsync();
            List<RegistrationViewModel> vmList = new List<RegistrationViewModel>();

            foreach (Training t in lst)
            {
                RegistrationViewModel model = new RegistrationViewModel();
                int attendanceCount = _context.Training_Volunteers.Where(i => i.trainingID == t.trainingID).Count();
                var capacity = t.Capacity;
                double capDiv = (double)attendanceCount / capacity;
                model.siteName = t.site.siteName;
                model.Date = t.Date.ToLongDateString();
                model.startTime = t.startTime.ToShortTimeString();
                model.endTime = t.endTime.ToShortTimeString();
                model.part = t.part;
                model.trainingID = t.trainingID;

                if ((capDiv) < 0.5)
                {
                    model.Capacity = "Lots of Space!";

                }
                else if (capDiv >= 0.5 && capDiv < 1)
                {
                    model.Capacity = "Almost Full!";
                }
                else if (capDiv == 1)
                {
                    model.Capacity = "Full!";
                }
                else
                {
                    model.Capacity = "null";
                }
                vmList.Add(model);
            }

            return View(vmList);
        }

        // GET: Registrations/Details/5
        public async Task<IActionResult> Details(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var approvedTraining = await _context.Trainings
                .Include(t => t.site)
                .Include(t => t.term)
                .FirstOrDefaultAsync(m => m.trainingID == id);

            if (approvedTraining == null)
            {
                return NotFound();
            }

            return View(approvedTraining);
        }

        public async Task<IActionResult> Register(int id, string loginStatus)
        {
            var userId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            //var user = appcontext.Users.Where(x => x.Id == userId);

                if (loginStatus == "loggedin")
                {
                
                    var trnVol = new Training_Volunteer();
                    trnVol.trainingID = id;
                    trnVol.volunteerID = userId;
                    trnVol.training = _context.Trainings.Where(x => x.trainingID == id).FirstOrDefault();

                    _context.Add(trnVol);
                    await _context.SaveChangesAsync();
                }
                else if (loginStatus == "NOTloggedin")
            {
                HttpContext.Session.SetString("training_id", id.ToString() );
                return Redirect("~/Identity/Account/Login");
            }

                var registeringTraining = await _context.Trainings
                    .Include(t => t.site)
                    .Include(t => t.term)
                    .FirstOrDefaultAsync(m => m.trainingID == id);

                Training_Volunteer registrationPart2 = new Training_Volunteer();

                var training = _context.Trainings.Where(x => x.linkID == id && x.part.ToString().Equals("part2")).FirstOrDefault();
                if (training != null)
                {
                    registrationPart2.trainingID = training.trainingID;
                    registrationPart2.volunteerID = userId;
                    registrationPart2.training = training;
                    _context.Add(registrationPart2);
                    await _context.SaveChangesAsync();

                }


                string month;
                string day;
                if (registeringTraining.Date.Month < 10)
                {
                    month = "0" + registeringTraining.Date.Month;
                }
                else
                {
                    month = registeringTraining.Date.Month.ToString();
                }

                if (registeringTraining.Date.Day < 10)
                {
                    day = "0" + registeringTraining.Date.Day;
                }
                else
                {
                    day = registeringTraining.Date.Day.ToString();
                }

                string date = month + "/" + day + "/" + registeringTraining.Date.Year;
                string startdate = date + " " + registeringTraining.startTime.ToShortTimeString();
                string enddate = date + " " + registeringTraining.endTime.ToShortTimeString();
                string location = registeringTraining.site.Address;
                string title = registeringTraining.site.siteName + " Training Session: StrongStart";

                HttpContext.Session.SetString("title", title);
                HttpContext.Session.SetString("end", enddate);
                HttpContext.Session.SetString("start", startdate);
                HttpContext.Session.SetString("location", location);

                /* if (trainingPart2.Date.Month < 10)
                 {
                     month = "0" + trainingPart2.Date.Month;
                 }
                 else
                 {
                     month = trainingPart2.Date.Month.ToString();
                 }

                 if (trainingPart2.Date.Day < 10)
                 {
                     day = "0" + trainingPart2.Date.Day;
                 }
                 else
                 {
                     day = trainingPart2.Date.Day.ToString();
                 }

                 string date = month + "/" + day + "/" + trainingPart2.Date.Year;
                 string startdate = date + " " + trainingPart2.startTime.ToShortTimeString();
                 string enddate = date + " " + trainingPart2.endTime.ToShortTimeString();
                 string location = trainingPart2.site.Address;
                 string title = trainingPart2.site.siteName + " Training Session: StrongStart";

                 HttpContext.Session.SetString("title2", title);
                 HttpContext.Session.SetString("end2", enddate);
                 HttpContext.Session.SetString("start2", startdate);
                 HttpContext.Session.SetString("location2", location);
                 */

            return View("Success");

        }


        public async Task<IActionResult> Success()
        {

            return View();
        }

        private bool RegistrationExists(int id)
        {
            return _context.Training_Volunteers.Any(e => e.ID == id);
        }
        public ActionResult RemoveTraining(int trainingId)
        {
            String volunteerId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            Training_Volunteer training = (Training_Volunteer)_context.Training_Volunteers.Where(i => i.volunteerID == volunteerId && i.trainingID == trainingId).FirstOrDefault();

            _context.Training_Volunteers.Remove(training);
            _context.SaveChanges();
            return RedirectToAction("Index", "AccountDashboards");
        }
    }
}

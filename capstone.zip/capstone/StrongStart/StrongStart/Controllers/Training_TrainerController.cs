﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongStart.Models;

namespace StrongStart.Controllers
{
    public class Training_TrainerController : Controller
    {
        private readonly StrongStartContext _context;

        public Training_TrainerController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: Training_Trainer
        public async Task<IActionResult> Index(int? id)
        {
            var strongStartContext = _context.Training_Trainers.Include(t => t.trainer).Include(t => t.training).Where(t => t.trainingID == id);
            ViewData["trainingSite"] = _context.Trainings.Include(t => t.site).FirstOrDefault(t => t.trainingID == id).site.siteName;
            ViewData["trainingDate"] = _context.Trainings.FirstOrDefault(t => t.trainingID == id).Date.ToShortDateString();
            ViewData["trainingID"] = id;
            
            return View(await strongStartContext.ToListAsync());
        }

        // GET: Training_Trainer/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var training_Trainer = await _context.Training_Trainers
                .Include(t => t.trainer)
                .Include(t => t.training)
                .Include(t => t.training.site)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (training_Trainer == null)
            {
                return NotFound();
            }

            return View(training_Trainer);
        }

        // GET: Training_Trainer/Create
        public IActionResult Create(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            
            ViewData["trainerID"] = new SelectList(_context.Trainers, "trainerID", "firstName");
            ViewData["trainingID"] = id;
            ViewData["trainingSite"] = _context.Trainings.Include(t => t.site).FirstOrDefault(t => t.trainingID == id).site.siteName;
            ViewData["trainingDate"] = _context.Trainings.FirstOrDefault(t => t.trainingID == id).Date.ToShortDateString();

            return View();
        }

        // POST: Training_Trainer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("trainerID,hasKit,driveDistance,becomeTrainer,traineeStatus")] Training_Trainer training_Trainer, int trainingID)
        {
            if (training_Trainer.becomeTrainer.ToString() == "No")
            {
                training_Trainer.traineeStatus = Status.NA;
            }
            if (training_Trainer.driveDistance == null)
            {
                training_Trainer.driveDistance = "0";
            }
            training_Trainer.trainingID = trainingID;

            Training_part Training_parts = _context.Training_parts.FirstOrDefault(t=>t.training_part_1_ID == trainingID);
            int training_Part2_ID = 0;
            if (Training_parts != null)
            {
               training_Part2_ID = Training_parts.training_part_2_ID;
            }
            
            if (ModelState.IsValid)
            {
                _context.Add(training_Trainer);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", new { id = trainingID });
            }
            ViewData["trainerID"] = new SelectList(_context.Trainers, "trainerID", "firstName", training_Trainer.trainerID);
            return View(training_Trainer);
        }

        // GET: Training_Trainer/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var training_Trainer = await _context.Training_Trainers.FindAsync(id);
            if (training_Trainer == null)
            {
                return NotFound();
            }
            ViewData["trainerID"] = new SelectList(_context.Trainers, "trainerID", "firstName", training_Trainer.trainerID);
            ViewData["trainingID"] = training_Trainer.trainingID;
            ViewData["trainingSite"] = _context.Trainings.Include(t => t.site).FirstOrDefault(t => t.trainingID == training_Trainer.trainingID).site.siteName;
            ViewData["trainingDate"] = _context.Trainings.FirstOrDefault(t => t.trainingID == training_Trainer.trainingID).Date.ToShortDateString();

            return View(training_Trainer);
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,trainerID,hasKit,driveDistance")] Training_Trainer training_Trainer,int trainingID)
        {
           
            if (id != training_Trainer.ID)
            {
                return NotFound();
            }
            if (training_Trainer.becomeTrainer.ToString() == "No")
            {
                training_Trainer.traineeStatus = Status.NA;
            }
            if (training_Trainer.driveDistance == null)
            {
                training_Trainer.driveDistance = "0";
            }
            training_Trainer.trainingID = trainingID;

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(training_Trainer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Training_TrainerExists(training_Trainer.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index",new { id = trainingID});
            }
            ViewData["trainerID"] = new SelectList(_context.Trainers, "trainerID", "firstName", training_Trainer.trainerID);
            return View(training_Trainer);
        }

        // GET: Training_Trainer/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var training_Trainer = await _context.Training_Trainers
                .Include(t => t.trainer)
                .Include(t => t.training)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (training_Trainer == null)
            {
                return NotFound();
            }

            return View(training_Trainer);
        }

        // POST: Training_Trainer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var training_Trainer = await _context.Training_Trainers.FindAsync(id);
            _context.Training_Trainers.Remove(training_Trainer);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", new { id = training_Trainer.trainingID });
        }

        private bool Training_TrainerExists(int id)
        {
            return _context.Training_Trainers.Any(e => e.ID == id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongStart.Models;
using StrongStart.Class;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace StrongStart.Controllers
{
    [Authorize]
    public class TrainingsController : Controller
    {
        private readonly StrongStartContext _context;

        public TrainingsController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: Trainings
        public async Task<IActionResult> Index(string SchoolName, string region)
        {
            DateTime dateTime = DateTime.Today;
            
            if (SchoolName != null)
            {
               var trainingListBySchool = await _context.Trainings.Include(t => t.site).Include(t => t.term).Where(t => t.site.siteName.Contains(SchoolName)).ToListAsync();
               return View(trainingListBySchool);
            }
            else
            {
                var trainingListAll = await _context.Trainings.Include(t => t.site).Include(t => t.term).ToListAsync();
                return View(trainingListAll);
            }
            
            return View();
        }
        

        // GET: Attandance
        public async Task<IActionResult> Attendance(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var Attendance = _context.Training_Volunteers.Include(r => r.training).Where(r => r.trainingID == Convert.ToInt32(id)).OrderBy(r=>r.volunteerID);
            var training = await _context.Trainings
                .Include(t => t.site)
                .Include(t => t.term)
                .FirstOrDefaultAsync(m => m.trainingID == id);
            HttpContext.Session.SetString("siteName", training.site.siteName);
            HttpContext.Session.SetString("Date", training.Date.ToShortDateString());
            HttpContext.Session.SetString("startTime", training.startTime.ToShortTimeString());
            HttpContext.Session.SetString("endTime", training.endTime.ToShortTimeString());
            HttpContext.Session.SetString("Part", training.part.ToString());
            return View(await Attendance.ToListAsync());
        }

        // GET: Trainings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var training = await _context.Trainings
                .Include(t => t.site)
                .Include(t => t.term)
                .FirstOrDefaultAsync(m => m.trainingID == id);
            if (training == null)
            {
                return NotFound();
            }
            return View(training);
        }

        // GET: Trainings/Create
        public IActionResult Create()
        {
            ViewData["siteID"] = new SelectList(_context.Sites, "siteID", "siteName");
            ViewData["termID"] = new SelectList(_context.Terms, "termID", "termName");
            ViewData["linkID"] = new SelectList(_context.Trainings.Where(x => x.part.ToString() == "part1" && x.trainingName != null), "trainingID", "trainingName");
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("trainingID,siteID,termID,startTime,endTime,Date,permit,specInstructions,part,Approved,Capacity,Finished,linkID")] Training training, string doAddPart2)
        {
            training.site = _context.Sites.Where(x => x.siteID == training.siteID).FirstOrDefault();
            training.trainingName = training.site.siteName; 
            if (training.part.ToString() == "part1")
            {
                training.linkID = null;
            }

            if (ModelState.IsValid)
            {
                _context.Add(training);
                await _context.SaveChangesAsync();

            }
            return RedirectToAction("Create", "Training_Trainer", new { id = training.trainingID });
            ViewData["siteID"] = new SelectList(_context.Sites, "siteID", "siteName");
            ViewData["termID"] = new SelectList(_context.Terms, "termID", "termName");
            ViewData["linkID"] = new SelectList(_context.Trainings.Where(x => x.part.ToString() == "part1"), "trainingID", "trainingName");
        }

        // GET: Trainings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var training = await _context.Trainings.FindAsync(id);
            if (training == null)
            {
                return NotFound();
            }
            ViewData["siteID"] = new SelectList(_context.Sites, "siteID", "siteName", training.siteID);
            ViewData["termID"] = new SelectList(_context.Terms, "termID", "termName", training.termID);
            return View(training);
        }

        // POST: Trainings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("trainingID,siteID,termID,startTime,endTime,Date,permit,specInstructions,part,trainer1_ID,trainer2_ID,Approved,Kit,Capacity,Finished")] Training training)
        {
            if (id != training.trainingID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(training);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TrainingExists(training.trainingID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["siteID"] = new SelectList(_context.Sites, "siteID", "siteName", training.siteID);
            ViewData["termID"] = new SelectList(_context.Terms, "termID", "termName", training.termID);
            return View(training);
        }

        // GET: Trainings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var training = await _context.Trainings
                .Include(t => t.site)
                .Include(t => t.term)
                .FirstOrDefaultAsync(m => m.trainingID == id);
            if (training == null)
            {
                return NotFound();
            }

            return View(training);
        }

        // POST: Trainings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var training = await _context.Trainings.FindAsync(id);
            _context.Trainings.Remove(training);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TrainingExists(int id)
        {
            return _context.Trainings.Any(e => e.trainingID == id);
        }
    }
}

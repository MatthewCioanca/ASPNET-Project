﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace StrongStart.Migrations
{
    public partial class StrongStartDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Regions",
                columns: table => new
                {
                    regionID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    regionCode = table.Column<string>(nullable: true),
                    regionName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Regions", x => x.regionID);
                });

            migrationBuilder.CreateTable(
                name: "Terms",
                columns: table => new
                {
                    termID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    termName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Terms", x => x.termID);
                });

            migrationBuilder.CreateTable(
                name: "Sites",
                columns: table => new
                {
                    siteID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    siteName = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Province = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    geoLat = table.Column<string>(nullable: true),
                    geoLng = table.Column<string>(nullable: true),
                    regionID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sites", x => x.siteID);
                    table.ForeignKey(
                        name: "FK_Sites_Regions_regionID",
                        column: x => x.regionID,
                        principalTable: "Regions",
                        principalColumn: "regionID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Trainers",
                columns: table => new
                {
                    trainerID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<int>(nullable: false),
                    firstName = table.Column<string>(nullable: true),
                    lastName = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Province = table.Column<string>(nullable: true),
                    Country = table.Column<string>(nullable: true),
                    regionID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trainers", x => x.trainerID);
                    table.ForeignKey(
                        name: "FK_Trainers_Regions_regionID",
                        column: x => x.regionID,
                        principalTable: "Regions",
                        principalColumn: "regionID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Trainings",
                columns: table => new
                {
                    trainingID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    siteID = table.Column<int>(nullable: false),
                    termID = table.Column<int>(nullable: false),
                    startTime = table.Column<DateTime>(nullable: false),
                    endTime = table.Column<DateTime>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    permit = table.Column<int>(nullable: false),
                    specInstructions = table.Column<string>(nullable: true),
                    part = table.Column<int>(nullable: false),
                    Capacity = table.Column<string>(nullable: false),
                    Approved = table.Column<int>(nullable: false),
                    Finished = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trainings", x => x.trainingID);
                    table.ForeignKey(
                        name: "FK_Trainings_Sites_siteID",
                        column: x => x.siteID,
                        principalTable: "Sites",
                        principalColumn: "siteID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Trainings_Terms_termID",
                        column: x => x.termID,
                        principalTable: "Terms",
                        principalColumn: "termID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Volunteers",
                columns: table => new
                {
                    volunteerID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    firstName = table.Column<string>(nullable: true),
                    lastName = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    PasswordSalt = table.Column<string>(nullable: true),
                    PasswordHash = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Province = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    infoID = table.Column<int>(nullable: false),
                    prefSchool = table.Column<int>(nullable: false),
                    siteID = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Volunteers", x => x.volunteerID);
                    table.ForeignKey(
                        name: "FK_Volunteers_Sites_siteID",
                        column: x => x.siteID,
                        principalTable: "Sites",
                        principalColumn: "siteID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Training_parts",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    training_part_1_ID = table.Column<int>(nullable: false),
                    training_part_2_ID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Training_parts", x => x.id);
                    table.ForeignKey(
                        name: "FK_Training_parts_Trainings_training_part_1_ID",
                        column: x => x.training_part_1_ID,
                        principalTable: "Trainings",
                        principalColumn: "trainingID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Training_parts_Trainings_training_part_2_ID",
                        column: x => x.training_part_2_ID,
                        principalTable: "Trainings",
                        principalColumn: "trainingID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Training_Trainers",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    trainingID = table.Column<int>(nullable: false),
                    trainerID = table.Column<int>(nullable: false),
                    becomeTrainer = table.Column<int>(nullable: false),
                    traineeStatus = table.Column<int>(nullable: false),
                    hasKit = table.Column<int>(nullable: false),
                    driveDistance = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Training_Trainers", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Training_Trainers_Trainers_trainerID",
                        column: x => x.trainerID,
                        principalTable: "Trainers",
                        principalColumn: "trainerID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Training_Trainers_Trainings_trainingID",
                        column: x => x.trainingID,
                        principalTable: "Trainings",
                        principalColumn: "trainingID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Training_Volunteers",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    volunteerID = table.Column<int>(nullable: false),
                    trainingID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Training_Volunteers", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Training_Volunteers_Trainings_trainingID",
                        column: x => x.trainingID,
                        principalTable: "Trainings",
                        principalColumn: "trainingID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Training_Volunteers_Volunteers_volunteerID",
                        column: x => x.volunteerID,
                        principalTable: "Volunteers",
                        principalColumn: "volunteerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Regions",
                columns: new[] { "regionID", "regionCode", "regionName" },
                values: new object[,]
                {
                    { 1, "KI", "Kitchener" },
                    { 2, "WA", "Waterloo" }
                });

            migrationBuilder.InsertData(
                table: "Terms",
                columns: new[] { "termID", "termName" },
                values: new object[,]
                {
                    { 1, "F2019" },
                    { 2, "S2019" },
                    { 3, "F2020" }
                });

            migrationBuilder.InsertData(
                table: "Sites",
                columns: new[] { "siteID", "Address", "City", "Phone", "PostalCode", "Province", "geoLat", "geoLng", "regionID", "siteName" },
                values: new object[,]
                {
                    { 1, "121 Followfield Dr", "Kitchener", "5197217729", "N2E2M8", "ON", null, null, 1, "YWCA" },
                    { 2, "299 Doon Valley", "Kitchener", "987456213", "N2E2M8", "ON", null, null, 1, "Conestoga College" }
                });

            migrationBuilder.InsertData(
                table: "Trainers",
                columns: new[] { "trainerID", "Address", "City", "Country", "Phone", "Province", "Title", "firstName", "lastName", "regionID" },
                values: new object[,]
                {
                    { 1, "5 Rittenhouse Rd", "Waterloo", "Canada", "123456789", "ON", 0, "qiao", "wang", 1 },
                    { 2, "10 Rittenhouse Rd", "Waterloo", "Canada", "123456789", "ON", 1, "mao", "qiu", 1 }
                });

            migrationBuilder.InsertData(
                table: "Trainings",
                columns: new[] { "trainingID", "Approved", "Capacity", "Date", "Finished", "endTime", "part", "permit", "siteID", "specInstructions", "startTime", "termID" },
                values: new object[] { 2, 0, "40", new DateTime(2019, 10, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, new DateTime(2019, 10, 12, 12, 0, 0, 0, DateTimeKind.Unspecified), 1, 1, 1, null, new DateTime(2019, 10, 12, 10, 0, 0, 0, DateTimeKind.Unspecified), 2 });

            migrationBuilder.InsertData(
                table: "Trainings",
                columns: new[] { "trainingID", "Approved", "Capacity", "Date", "Finished", "endTime", "part", "permit", "siteID", "specInstructions", "startTime", "termID" },
                values: new object[] { 1, 0, "30", new DateTime(2019, 10, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, new DateTime(2019, 10, 5, 12, 0, 0, 0, DateTimeKind.Unspecified), 0, 1, 2, null, new DateTime(2019, 10, 5, 10, 0, 0, 0, DateTimeKind.Unspecified), 1 });

            migrationBuilder.InsertData(
                table: "Training_parts",
                columns: new[] { "id", "training_part_1_ID", "training_part_2_ID" },
                values: new object[] { 1, 1, 2 });

            migrationBuilder.CreateIndex(
                name: "IX_Sites_regionID",
                table: "Sites",
                column: "regionID");

            migrationBuilder.CreateIndex(
                name: "IX_Trainers_regionID",
                table: "Trainers",
                column: "regionID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_training_part_1_ID",
                table: "Training_parts",
                column: "training_part_1_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_training_part_2_ID",
                table: "Training_parts",
                column: "training_part_2_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_Trainers_trainerID",
                table: "Training_Trainers",
                column: "trainerID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_Trainers_trainingID",
                table: "Training_Trainers",
                column: "trainingID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_Volunteers_trainingID",
                table: "Training_Volunteers",
                column: "trainingID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_Volunteers_volunteerID",
                table: "Training_Volunteers",
                column: "volunteerID");

            migrationBuilder.CreateIndex(
                name: "IX_Trainings_siteID",
                table: "Trainings",
                column: "siteID");

            migrationBuilder.CreateIndex(
                name: "IX_Trainings_termID",
                table: "Trainings",
                column: "termID");

            migrationBuilder.CreateIndex(
                name: "IX_Volunteers_siteID",
                table: "Volunteers",
                column: "siteID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Training_parts");

            migrationBuilder.DropTable(
                name: "Training_Trainers");

            migrationBuilder.DropTable(
                name: "Training_Volunteers");

            migrationBuilder.DropTable(
                name: "Trainers");

            migrationBuilder.DropTable(
                name: "Trainings");

            migrationBuilder.DropTable(
                name: "Volunteers");

            migrationBuilder.DropTable(
                name: "Terms");

            migrationBuilder.DropTable(
                name: "Sites");

            migrationBuilder.DropTable(
                name: "Regions");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace StrongStart.Migrations
{
    public partial class DB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Training_parts_Trainings_training_part_1_ID",
                table: "Training_parts");

            migrationBuilder.DropForeignKey(
                name: "FK_Training_parts_Trainings_training_part_2_ID",
                table: "Training_parts");

            migrationBuilder.DropIndex(
                name: "IX_Training_parts_training_part_1_ID",
                table: "Training_parts");

            migrationBuilder.DropIndex(
                name: "IX_Training_parts_training_part_2_ID",
                table: "Training_parts");

            migrationBuilder.AlterColumn<int>(
                name: "Capacity",
                table: "Trainings",
                nullable: false,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<int>(
                name: "linkID",
                table: "Trainings",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Training_Part_1trainingID",
                table: "Training_parts",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Training_Part_2trainingID",
                table: "Training_parts",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Trainings",
                keyColumn: "trainingID",
                keyValue: 1,
                column: "Capacity",
                value: 30);

            migrationBuilder.UpdateData(
                table: "Trainings",
                keyColumn: "trainingID",
                keyValue: 2,
                column: "Capacity",
                value: 40);

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_Training_Part_1trainingID",
                table: "Training_parts",
                column: "Training_Part_1trainingID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_Training_Part_2trainingID",
                table: "Training_parts",
                column: "Training_Part_2trainingID");

            migrationBuilder.AddForeignKey(
                name: "FK_Training_parts_Trainings_Training_Part_1trainingID",
                table: "Training_parts",
                column: "Training_Part_1trainingID",
                principalTable: "Trainings",
                principalColumn: "trainingID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Training_parts_Trainings_Training_Part_2trainingID",
                table: "Training_parts",
                column: "Training_Part_2trainingID",
                principalTable: "Trainings",
                principalColumn: "trainingID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Training_parts_Trainings_Training_Part_1trainingID",
                table: "Training_parts");

            migrationBuilder.DropForeignKey(
                name: "FK_Training_parts_Trainings_Training_Part_2trainingID",
                table: "Training_parts");

            migrationBuilder.DropIndex(
                name: "IX_Training_parts_Training_Part_1trainingID",
                table: "Training_parts");

            migrationBuilder.DropIndex(
                name: "IX_Training_parts_Training_Part_2trainingID",
                table: "Training_parts");

            migrationBuilder.DropColumn(
                name: "linkID",
                table: "Trainings");

            migrationBuilder.DropColumn(
                name: "Training_Part_1trainingID",
                table: "Training_parts");

            migrationBuilder.DropColumn(
                name: "Training_Part_2trainingID",
                table: "Training_parts");

            migrationBuilder.AlterColumn<string>(
                name: "Capacity",
                table: "Trainings",
                nullable: false,
                oldClrType: typeof(int));

            migrationBuilder.UpdateData(
                table: "Trainings",
                keyColumn: "trainingID",
                keyValue: 1,
                column: "Capacity",
                value: "30");

            migrationBuilder.UpdateData(
                table: "Trainings",
                keyColumn: "trainingID",
                keyValue: 2,
                column: "Capacity",
                value: "40");

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_training_part_1_ID",
                table: "Training_parts",
                column: "training_part_1_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Training_parts_training_part_2_ID",
                table: "Training_parts",
                column: "training_part_2_ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Training_parts_Trainings_training_part_1_ID",
                table: "Training_parts",
                column: "training_part_1_ID",
                principalTable: "Trainings",
                principalColumn: "trainingID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Training_parts_Trainings_training_part_2_ID",
                table: "Training_parts",
                column: "training_part_2_ID",
                principalTable: "Trainings",
                principalColumn: "trainingID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

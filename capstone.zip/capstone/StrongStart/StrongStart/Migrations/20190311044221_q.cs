﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace StrongStart.Migrations
{
    public partial class q : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Training_Volunteers_Volunteers_volunteerID",
                table: "Training_Volunteers");

            migrationBuilder.DropIndex(
                name: "IX_Training_Volunteers_volunteerID",
                table: "Training_Volunteers");

            migrationBuilder.AlterColumn<string>(
                name: "volunteerID",
                table: "Training_Volunteers",
                nullable: true,
                oldClrType: typeof(int));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "volunteerID",
                table: "Training_Volunteers",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Training_Volunteers_volunteerID",
                table: "Training_Volunteers",
                column: "volunteerID");

            migrationBuilder.AddForeignKey(
                name: "FK_Training_Volunteers_Volunteers_volunteerID",
                table: "Training_Volunteers",
                column: "volunteerID",
                principalTable: "Volunteers",
                principalColumn: "volunteerID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StrongStart.Models
{
    public class Site
    {
        public int siteID { get; set; }
        [Display(Name = "Site Name")]
        public string siteName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        public string geoLat { get; set; }
        public string geoLng { get; set; }

        public int regionID { get; set; }
        public Region region { get; set; }

        public ICollection<Training> Trainings { get; set; }
        public ICollection<Volunteer> Volunteers { get; set; }
    }
}

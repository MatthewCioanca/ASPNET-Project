﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StrongStart.Models;

namespace StrongStart.Models
{
    public class StrongStartContext:DbContext
    {
        public StrongStartContext(DbContextOptions<StrongStartContext> options)
            : base(options)
        { }

        public DbSet<Region> Regions { get; set; }
        public DbSet<Training_Volunteer> Training_Volunteers { get; set; }
        public DbSet<Site> Sites { get; set; }
        public DbSet<Term> Terms { get; set; }
        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<Training> Trainings { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<Training_part> Training_parts { get; set; }
        public DbSet<Training_Trainer> Training_Trainers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Training_part>()
            //   .HasOne(trl => trl.Training_Part_1)
            //   .WithMany(t => t.Training_part_1)
            //   .HasForeignKey(trl => trl.training_part_1_ID)
            //   .OnDelete(DeleteBehavior.Restrict);

            //modelBuilder.Entity<Training_part>()
            //  .HasOne(trl => trl.Training_Part_2)
            //  .WithMany(t => t.Training_part_2)
            //  .HasForeignKey(trl => trl.training_part_2_ID)
            //  .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Site>()
               .HasOne(s => s.region)
               .WithMany(r => r.Sites)
               .HasForeignKey(s => s.regionID)
               .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Training>()
                .HasOne(ti => ti.term)
                .WithMany(t => t.Trainings)
                .HasForeignKey(ti => ti.termID)
                .OnDelete(DeleteBehavior.Restrict);
            
      /*      modelBuilder.Entity<Training_Volunteer>()
               .HasOne(r => r.volunteer)
               .WithMany(v => v.Training_Volunteers)
               .HasForeignKey(v => v.volunteerID)
               .OnDelete(DeleteBehavior.Restrict); */

            modelBuilder.Entity<Region>().HasData(
                new Region() { regionID= 1, regionCode = "KI",regionName="Kitchener"},
                new Region() { regionID = 2, regionCode = "WA", regionName = "Waterloo" }
                );

            modelBuilder.Entity<Site>().HasData(
                new Site() { siteID=1, siteName="YWCA", Address="121 Followfield Dr",Phone="5197217729",City="Kitchener",Province="ON",PostalCode="N2E2M8",regionID=1},
                new Site() { siteID = 2, siteName = "Conestoga College", Address = "299 Doon Valley", Phone = "987456213", City = "Kitchener", Province = "ON", PostalCode = "N2E2M8", regionID = 1 }
                );
            modelBuilder.Entity<Trainer>().HasData(
                new Trainer() { trainerID = 1, Title = Title.Trainer, firstName = "qiao", lastName = "wang", Address = "5 Rittenhouse Rd", Phone = "123456789", City = "Waterloo", Province = "ON", Country = "Canada", regionID = 1 },
                new Trainer() { trainerID = 2, Title = Title.Trainee, firstName = "mao", lastName = "qiu", Address = "10 Rittenhouse Rd", Phone = "123456789", City = "Waterloo", Province = "ON", Country = "Canada", regionID = 1 }
                );
            modelBuilder.Entity<Term>().HasData(
                new Term() { termID=1,termName="F2019" },
                new Term() { termID = 2, termName = "S2019" },
                new Term() { termID = 3, termName = "F2020" }
                );
            modelBuilder.Entity<Training>().HasData(
               new Training()
               {
                   trainingID = 1,
                   siteID = 2,
                   termID = 1,
                   startTime = new DateTime(2019, 10, 5, 10, 0, 0),
                   endTime = new DateTime(2019, 10, 5, 12, 0, 0),
                   Date = new DateTime(2019, 10, 5),
                   permit = YesNO.Yes,
                   specInstructions = null,
                   part = Part.part1,
                   Approved = YesNO.No,
                   Capacity = 30,
                   Finished = YesNO.No
               },
                new Training()
                {
                    trainingID = 2,
                    siteID = 1,
                    termID = 2,
                    startTime = new DateTime(2019, 10, 12, 10, 0, 0),
                    endTime = new DateTime(2019, 10, 12, 12, 0, 0),
                    Date = new DateTime(2019, 10, 12),
                    permit = YesNO.Yes,
                    specInstructions = null,
                    part = Part.part2,
                    Approved = YesNO.No,
                    Capacity = 40,
                    Finished = YesNO.No
                }
                );
            modelBuilder.Entity<Training_part>().HasData(
                new Training_part() {id=1,training_part_1_ID=1,training_part_2_ID=2  }
                );

        }

        
    }
}

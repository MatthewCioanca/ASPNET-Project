﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StrongStart.Models
{
    public class Training_part
    {
        public int id { get; set; }

        public int training_part_1_ID { get; set; }
        public Training Training_Part_1 { get; set; }

        public int training_part_2_ID { get; set; }
        public Training Training_Part_2 { get; set; }
    }
}
